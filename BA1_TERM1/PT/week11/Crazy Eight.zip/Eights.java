import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Eights
{
    private Player one;
    private Player two;
    private Hand drawPile;
    private Hand discardPile;
    private Scanner in;

    public boolean isDone()
    {
        return one.getHand().empty() || two.getHand().empty();
    }

    public void reshuffle()
    {
        Card prev = discardPile.popCard();
        discardPile.dealAll(drawPile);
        discardPile.addCard(prev);
        drawPile.shuffle();
    }


    public Card drawCard()
    {
        if (drawPile.empty())
        {
            reshuffle();
        }
        return drawPile.popCard();
    }

    public Player nextPlayer(Player current)
    {
        if (current == one) {
            return two;
        } else {
            return one;
        }
    }

    public void takeTurn(Player player)
    {
        Card prev = discardPile.lastCard();
        Card next = player.play(this, prev);
        discardPile.addCard(next);

        System.out.println(player.getName() + " plays " + next);
        System.out.println();
    }

    public void playGame()
    {
        Player player = one;

        // keep playing until there's a winner
        while (!isDone())
        {
            displayState();
            takeTurn(player);
            player = nextPlayer(player);
        }

        // display the final score
        one.displayScore();
        two.displayScore();
    }

    public void displayState()
    {
        
    }
}