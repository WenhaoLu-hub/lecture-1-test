public class Hyena extends Animal {

    public Hyena(String name, int age){
       super(name, age);
    }
}
