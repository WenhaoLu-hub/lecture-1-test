public class Lion extends Animal { // Is a relationship

    public Lion(String name, int age){
        super(name, age);
    }

    public String roar(){
        return "I'm working on my roar wwwrooow.";
    }
}
