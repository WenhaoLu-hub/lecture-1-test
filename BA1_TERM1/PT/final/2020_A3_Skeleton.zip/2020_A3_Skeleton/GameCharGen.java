import java.util.Scanner;

public class GameCharGen 
{
	public void displayMenu()
	{
		
	}

	public void run() throws NoGameCharacterFoundException
	{
		GameCharGenModel myCharGen = new GameCharGenModel();
		Scanner menuInput = new Scanner(System.in);
		
		// Implement Q1 & Q4 menu updates here
		// Q2, Q3, & Q4 will be implemented in the GameCharGenModel class
		
	}
}
