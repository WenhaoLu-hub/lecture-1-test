public class Driver
{
    public static void main(String[] args)
    {
        LeagueOfJustice leagueOfJustice = new LeagueOfJustice();
        leagueOfJustice.run();
    }
}