/**
 * PUT YOUR STUDENT NAME & NUMBER HERE
 */
public class A2 
{
    /*
     *  YOU MAY MODIFY THIS DATA FOR TESTING PURPOSES
     *  YOU MUST MAKE SURE YOUR FINAL SUBMISSION CONTAINS
     *  THIS DATASET UNMODIFIED.
     */   
    private String[] menu=
    {
        "INDIAN|Biryani|16.99",
        "VIETNAMESE||17.00",
        "CHINESE|Chicken with Black Bean Sauce|16.5",
        "MIDDLE_EASTERN|Falafel|17.99",
        "Indian|Butter Chicken|17.00",
        "THAI|Pad Thai|23.00",
        "|Orange & Poppyseed Cake|15.99",
        "GREEK|Moussaka|18.50",
        "JAPANESE|Sushi|",
        "ITALIAN|Lasagne|18.50",
        "INDIAN|Dhal Tadka|9.50",
        "INDIAN|Brinjal|11.50"
    }; 
    
    /*
     *  YOU MAY MODIFY CODE IN THIS METHOD FOR TESTING PURPOSES
     *  YOU MUST MAKE SURE YOUR FINAL SUBMISSION CONTAINS
     *  THIS METHOD IN ITS UNMODIFIED STATE.
     */   
    public void run()
    {
        String preliminary = "\n\nPLEASE NOTE: This code represents initial test data\n" +
        "You need to thoroughly test your solution.\n" +
        "During assessment we will change the values in these\n" +
        "tests and change the underlying dataset.\n" +
        "When you submit your final version make sure that\n" +
        "the code in this run method has not been changed.\n\n" +
        "You should also focus on best practice code by writing \n" +
        "cohesive methods and following the principles taught in this course\n\n";

        System.out.println(preliminary);
        /**
         * TESTING Meal Summary
         */
        System.out.println("TESTING - MEAL SUMMARY (VALID)");
        System.out.println("(16.99 - 18.50)");
        String result = getMealSummaryInRange(16.99, 18.50);
        System.out.println(result);

        System.out.println("TESTING - MEAL SUMMARY (NOT FOUND)");
        System.out.println("(30.00 - 50.00)");
        result = getMealSummaryInRange(30.00, 50.00);
        System.out.println(result);
        System.out.println("------------");

        /**
         * TESTING Get Change
         */
        System.out.println("TESTING - GET CHANGE (VALID)");
        System.out.println("(Biryani,Falafel, Moussaka, Lasagne)");
        String[] mealsOrdered = {"Biryani","Falafel", "Moussaka", "Lasagne"};
        result = getChange(mealsOrdered, 123.00);
        System.out.println(result);
        
        System.out.println("TESTING - GET CHANGE (INSUFFICIENT FUNDS)");
        System.out.println("(Biryani,Falafel, Moussaka, Lasagne)");
        result = getChange(mealsOrdered, 53.99);
        System.out.println(result);

        System.out.println("\nTESTING - GET CHANGE (EMPTY)");
        mealsOrdered[0] = "";
        mealsOrdered[1] = "";
        mealsOrdered[2] = "";
        mealsOrdered[3] = "";
        result = getChange(mealsOrdered, 123.00);
        System.out.println(result);

        System.out.println("\nTESTING - GET CHANGE (NULL)");
        mealsOrdered = null;
        result = getChange(mealsOrdered, 123.00);
        System.out.println(result);
        System.out.println("------------");

         /**
         * TESTING Get Change
         */
        System.out.println("\nTESTING - MEALS BY CUISINE");
        System.out.println("(INDIAN)");
        String[] mealsByCuisine = getMealsByCuisine("INDIAN");
        for(int i =0; i < mealsByCuisine.length;i++){
            System.out.println(mealsByCuisine[i]);
        }

        System.out.println("\nTESTING - MEALS BY CUISINE");
        System.out.println("(RUSSIAN)");
        mealsByCuisine = getMealsByCuisine("RUSSIAN");
        for(int i =0; i < mealsByCuisine.length;i++){
            System.out.println(mealsByCuisine[i]);
        }

        System.out.println("\nTESTING - MEALS BY CUISINE");
        System.out.println("(Empty)");
        mealsByCuisine = getMealsByCuisine("");
        for(int i =0; i < mealsByCuisine.length;i++){
            System.out.println(mealsByCuisine[i]);
        }

        System.out.println("\nTESTING - MEALS BY CUISINE");
        System.out.println("(NULL)");
        mealsByCuisine = getMealsByCuisine(null);
        for(int i =0; i < mealsByCuisine.length;i++){
            System.out.println(mealsByCuisine[i]);
        }

        System.out.println("------------");

        System.out.println("\nTESTING - MEALS HISTOGRAM");
        result = mealsAvailableHistogram();
        System.out.println(result);
        System.out.println("------------");
        
    }

    /**
     * Implement Q1, you must implement the body of this method
     * NOTE: EACH OF THE PRIMARY METHODS FOR THE QUESTIONS WILL
     * BE TESTED INDIVIUDALLY WITHOUT REFERENCE TO ANY PRE-VALIDATION
     * YOU MIGHT IMPLEMENT
     */
    private String getMealSummaryInRange(double startPrice, double upperPrice)
    {
         // Implement the method logic here
        String result = "";
       

        return result;
    }

    /**
     * Implement Q2, you must implement the body of this method
     * NOTE: EACH OF THE PRIMARY METHODS FOR THE QUESTIONS WILL
     * BE TESTED INDIVIUDALLY WITHOUT REFERENCE TO ANY PRE-VALIDATION
     * YOU MIGHT IMPLEMENT
     */
    private String getChange(String[] meals, double paid) {
        // Implement the method logic here
        String result = "";
        
        
        return result;
    }

     /**
     * Implement Q3, you must implement the body of this method
     * NOTE: EACH OF THE PRIMARY METHODS FOR THE QUESTIONS WILL
     * BE TESTED INDIVIUDALLY WITHOUT REFERENCE TO ANY PRE-VALIDATION
     * YOU MIGHT IMPLEMENT
     */
    private String[] getMealsByCuisine(String cuisine)
    {
        // Implement the method logic here
        
        // you will need to modify this initialisation
        String[] result = new String[0];
       

        return result;
    }
    
     /**
     * Implement Q4, you must implement the body of this method
     * NOTE: EACH OF THE PRIMARY METHODS FOR THE QUESTIONS WILL
     * BE TESTED INDIVIUDALLY WITHOUT REFERENCE TO ANY PRE-VALIDATION
     * YOU MIGHT IMPLEMENT
     */
    private String mealsAvailableHistogram()
    {
         // Implement your method logic here
        String stringResult = "";

       
        return stringResult;
    }  
}