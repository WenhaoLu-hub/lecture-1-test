
/**
 * PUT YOUR STUDENT NAME & NUMBER HERE
 */
class Driver {
    public static void main(String[] args) {
        new A2().run();
    }

}