
/**
 * PUT YOUR STUDENT NAME & NUMBER HERE
 * Student name: Wenhao LU
 * Student number:S3810097
 */
class Driver {
    public static void main(String[] args) {
        new A2().run();
    }

}