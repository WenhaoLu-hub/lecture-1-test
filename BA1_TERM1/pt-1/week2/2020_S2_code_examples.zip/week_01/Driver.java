public class Driver
{
	public static void main(String[] args)
	{
		LeagueOfJustice1 leagueOfJustice = new LeagueOfJustice1();
		leagueOfJustice.run();
	}
}
