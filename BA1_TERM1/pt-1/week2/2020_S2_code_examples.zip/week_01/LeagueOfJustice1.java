

import java.util.Scanner;

public class LeagueOfJustice1 {
	public void run() {
		getAverageSpeedRounded();
	}

	/*
	 * ALGORITHM 
	 * 		Begin 
	 * 			Step 1: Get data from the user 
	 * 					GET first speed 
	 * 					GET second speed 
	 * 					GET name of super hero 
	 * 			Step2: Computation 
	 * 					ASSIGN n to the number of speeds 
	 * 					ASSIGN s to the sum of speeds 
	 * 					ASSIGN the result of s divided by n Step
	 * 			Step 3: Prepare display of data 
	 * 					FORMAT average speed to 2 decimal places
	 * 					CONCATENATE message + super hero name + average speed 
	 * 		End
	 */
	public void getAverageSpeedRounded() {
		// GET user input
		Scanner scanner = new Scanner(System.in);

		// SUMMARY OF DATA TYPES
		byte byteNumber = 127;
		// short shortNumber = 32767;
		int number = 2147483647;
		// long longNumber = 9223372036854775807l;

		// double doubleNumber = 1.7976931348623157E309;
		// float floatNumber = 3.4028235E39f;
		
		// boolean trueOrFalse = "true";

		// char singleCharacter = 'a';

		// BAD VARIABLE DECLARATION
		// double x, y;
		// double FirstSpeed, SecondSpeed;
		// double first-speed, second-speed;

		// INAPPROPRIATE VARIABLE DECLARATION
		// double speedFirst, speedSecond;
		// speedFirst = 1;
		// speedSecond = 3;
		// System.out.println("1 / 3 = " + speedFirst / speedSecond);

		// ILLOGICAL DECARLATION AND ASSIGNMENT
		// boolean speed = 100;

		// MIXING DATA TYPES
		// int mixed = 1 + 6.5;
		// double mixedOK = 1 + 6.5;

		// String hello = "Hello " + (1 + 2);
        // // hello = "Hello " + 1 + 2;
        // hello = 1 + 2 + "Hello ";
		// System.out.println(hello);
		
		// TYPES OF ERRORS (COMPILE/RUN/LOGICAL)
		// int a = 1 / 0;
		// double average = 1.0 + 2.0 + (100.0 / 3);
		// System.out.println(average);

		// Declare Only (Multiple declarations on a single line)
		double firstSpeed, secondSpeed;

		System.out.println("Please enter the first speed");
		// Assign a value to a variable
		firstSpeed = scanner.nextDouble();

		System.out.println("Please enter the second speed");
		secondSpeed = scanner.nextDouble();

		System.out.println("Please enter the name of superhero");
		scanner.nextLine();

		// Declare a variable and assign a value in one step
		String superheroName = scanner.nextLine();

		// COMPUTE average speed
		int numberOfItems = 2;
		double sumOfSpeeds = firstSpeed + secondSpeed;
		double averageSpeed = sumOfSpeeds / numberOfItems;

		// PROCESS the result
		String result = "The average speed of " + superheroName + " is: \n" + averageSpeed;
		// String result = "The average speed of " + superheroName + " is: \n" + String.valueOf(averageSpeed);
		// String result = "The average speed of " + superheroName + " is: \n" + Double.toString(averageSpeed);
		// String result = String.format("The average speed of " + superheroName + " is:\n %10.2f kmph", averageSpeed);
		System.out.println(result);
		
		scanner.close();

		/**
		 * Command line java tools
		 * java (run file without extension)
		 * javac (compile file with extension)
		 * javap - c (view byte code without extension)
		 */
	}
}
