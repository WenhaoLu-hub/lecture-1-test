public class Driver
{
    public static void main(String[] args)
    {

        // FormatSpecifier formatSpecifier = new FormatSpecifier();
        // formatSpecifier.run();
        // LoopExample loopExample = new LoopExample();
        // loopExample.run();

        // Patterns patterns = new Patterns();
        // patterns.run();
        LeagueOfJustice leagueOfJustice = new LeagueOfJustice();
        leagueOfJustice.run();
    }
}